"""
personal.py
------------
Antes, self.escola / self.trabalho / self.diaTreino nunca eram
preenchidos por ninguém, então o calendário sempre saía "Dia livre"
o tempo todo. Agora existem métodos para o usuário configurar
sua rotina de verdade, e o perfil pode ser salvo/recarregado.
"""

DIAS_SEMANA = ["segunda", "terca", "quarta", "quinta", "sexta", "sabado", "domingo"]


class Pessoa:
    def __init__(self, nome, idade, altura, peso, objetivo):
        self.nome = nome
        self.idade = idade
        self.altura = altura
        self.peso = peso
        self.objetivo = objetivo


class Personal(Pessoa):
    def __init__(self, nome, idade, altura, peso, objetivo):
        super().__init__(nome, idade, altura, peso, objetivo)

        self.academia = "nao"
        self.diaTreino = []
        self.horarios = ""
        self.escola = {}
        self.trabalho = {}

    # ---------------- Configuração da rotina ----------------

    @staticmethod
    def _ler_dias(texto):
        return [d.strip().lower() for d in texto.split(",") if d.strip()]

    def configurar_escola(self):
        resposta = input("\nVocê estuda? (sim/nao): ").strip().lower()
        if resposta.startswith("s"):
            dias = input("Em quais dias? (ex: segunda,terca,quarta): ")
            horario = input("Qual o horário das aulas? (ex: 19h-22h): ").strip()
            for dia in self._ler_dias(dias):
                self.escola[dia] = horario

    def configurar_trabalho(self):
        resposta = input("\nVocê trabalha? (sim/nao): ").strip().lower()
        if resposta.startswith("s"):
            dias = input("Em quais dias? (ex: segunda,terca,quarta,quinta,sexta): ")
            horario = input("Qual o horário de trabalho? (ex: 08h-17h): ").strip()
            for dia in self._ler_dias(dias):
                self.trabalho[dia] = horario

    def configurar_academia(self):
        resposta = input("\nVocê treina na academia? (sim/nao): ").strip().lower()
        self.academia = "sim" if resposta.startswith("s") else "nao"

        if self.academia == "sim":
            dias = input("Quais dias você treina? (ex: segunda,quarta,sexta): ")
            self.diaTreino = self._ler_dias(dias)
            self.horarios = input("Qual o horário de treino? (ex: 18h-19h): ").strip()

    def configurar_rotina_completa(self):
        self.configurar_escola()
        self.configurar_trabalho()
        self.configurar_academia()

    # ---------------- Exibição ----------------

    def calendario(self):
        print("\n========== CALENDÁRIO ==========")

        for dia in DIAS_SEMANA:
            print("\n" + dia.upper())
            ocupado = False

            if dia in self.escola:
                print("Escola:", self.escola[dia])
                ocupado = True

            if dia in self.trabalho:
                print("Trabalho:", self.trabalho[dia])
                ocupado = True

            if dia in self.diaTreino:
                print("Academia:", self.horarios)
                ocupado = True

            if not ocupado:
                print("Dia livre")

    # mantém compatibilidade com o nome usado antes em algum lugar do código
    mostrar_calendario = calendario

    # ---------------- Persistência ----------------

    def to_dict(self):
        return {
            "nome": self.nome,
            "idade": self.idade,
            "altura": self.altura,
            "peso": self.peso,
            "objetivo": self.objetivo,
            "academia": self.academia,
            "diaTreino": self.diaTreino,
            "horarios": self.horarios,
            "escola": self.escola,
            "trabalho": self.trabalho,
        }

    @classmethod
    def from_dict(cls, dados):
        perfil = cls(
            dados["nome"], dados["idade"], dados["altura"], dados["peso"], dados["objetivo"]
        )
        perfil.academia = dados.get("academia", "nao")
        perfil.diaTreino = dados.get("diaTreino", [])
        perfil.horarios = dados.get("horarios", "")
        perfil.escola = dados.get("escola", {})
        perfil.trabalho = dados.get("trabalho", {})
        return perfil
